# تطبيق iOS — البيك
غلاف Capacitor بيفتح موقع الزباين جوه تطبيق.

1. ارفع محتويات المجلد ده على مستودع GitHub جديد (فرع `main`).
2. من **Actions** شغّل «Build iOS app (unsigned)» ← حمّل `elbeik-ios-unsigned`.
ملحوظة مهمة: ملف الـ ipa ده **غير موقّع**؛ لتثبيته على آيفون أو رفعه على App Store لازم حساب Apple Developer وشهادة توقيع (أو أداة توقيع زي AltStore/Sideloadly للتجربة).

لتغيير رابط الموقع: عدّل `server.url` في `capacitor.config.json`.
تم إنشاء الموقع بواسطة Marwan | DX
